#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include"linkedList.h"

LNode* L;
Status InitList(LinkedList L) {
	L = (LNode*)malloc(sizeof(LNode));
	if (!L) {
		return ERROR;
	}
	else {
		L->next = NULL;
		return SUCCESS;
	}
}
void DestroyList(LinkedList L) {
	LNode* p;
	while (L) {
		p = L;
		L = L->next;
		free(p);
	}
}
Status InsertList(LNode* p, LNode* q) {
	ElemType e;
	if (p->next != NULL && p->next->next != NULL) {
		q = p->next;
		e = q->data;
		p->next = q->next;
		free(p);
	}
}
Status DeleteList(LNode* p, ElemType* e) {
	int i; int j = 0; LNode* q;
	scanf_s("%d", &i);
	p = L;
	while (p->next && j < i - 1) {
		p = p->next; ++j;
	}if (!(p->next) || j > i - 1) {
		return ERROR;
	}q = p->next;
	p->next = q->next;
	e = q->data;
	free(q);
	return SUCCESS;
}
void TraverseList(LinkedList L, void (*visit)(ElemType e)) {

}

Status SearchList(LinkedList L, ElemType e) {
	LNode* pre = NULL;
	LNode* cur = L;
	while (cur != NULL) {
		LNode* temp = cur->next;
		cur->next = pre;
		pre = cur;
		cur = temp;
	}
}
LNode* ReverseEvenList(LinkedList* L){
	LinkedList fast=L;
	LinkedList slow = L;
	while (fast != NULL && fast->next != NULL) {   //������fast->next=NULLʱ�ٻ�ȡ���ĺ����ڵ�ʱ����
		fast = fast->next->next;
		slow = slow->next;
	}
	return slow->data;
}

Status ReverseList(LinkedList* L) {
	LinkedList fast = L;
	LinkedList slow = L;
	int judje;
	while (fast->next != NULL && slow->next != NULL) {
		fast->next->next;
		slow->next;
		if (fast == NULL) {
			printf("����û�л�\n");
			judje = ERROR;
			break;
		}
		if (fast == slow) {
			printf("�����л�\n");
			judje = SUCCESS;
		}
	}
	return judje;
}


int main() {
	ElemType e=0;
	LinkedList L=(LNode*)malloc(sizeof(LNode));
	InitList(L);
	SearchList(L, e);
	ReverseList(L);
	LNode* ReverseEvenList(L);
	return 0;
}