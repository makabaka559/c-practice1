#include"duLinkedList.h"
#include<stdio.h>
#include<stdlib.h>
ElemType judje;
Status InitList_DuL(DuLinkedList L) {
	L = (DuLNode*)malloc(sizeof(DuLNode));
	L->prior = NULL;
	L->next = NULL;
	if (!L) {
		judje = ERROR;
	}
	if (L->next != NULL) {
		judje = SUCCESS;
	}
	return judje;
}

void DestroyList_DuL(DuLinkedList L) {
	while ((*L)->next != NULL) {
		if (*L == NULL) {
			printf("�ýڵ�Ƿ�\n");
			judje = ERROR;
		}
		if (&L->next == NULL) {
			printf("�ýڵ����޺����ڵ�\n");
			judge = ERROR;
		}
		DuLNode* p = L->next;
		L->next = p->next;  //�ı�L��p��λ�ã�ԭL->next�����ں����ͷ�p
		if (p->next) {
			p->next->prior = L;
			free(p);
			judje = SUCCESS;
		}
	}
	return judje;
}
Status InsertBeforeList_DuL(DuLNode* p, DuLNode* q) {
	struct DuLNode* p = (struct DuLNode*)malloc(sizeof(struct DuLNode));
	//struct Node* last = head;
	p-> data = p;
}